package junit;

public @interface Catagory {

}
