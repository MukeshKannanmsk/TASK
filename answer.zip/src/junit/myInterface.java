package junit;

public interface myInterface {

}
