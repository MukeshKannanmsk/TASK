package myarraylisttester;

public class CustomObject {
	String myString;
  public CustomObject(String myString) {
	  this.myString = myString;
  }
  public String toString() {
      return "CustomObject(myString='" + myString + "')";
  }
}
