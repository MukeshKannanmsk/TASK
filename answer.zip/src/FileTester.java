import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

public class FileTester {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		FileTask obj = new FileTask();
		 try {
			  String myPath = "/home/mukesh-pt7280/Desktop/day1/Sample.txt";
		      FileWriter myWriter = obj.getFileWriter(myPath);
		      System.out.print("enter the no of lines in the file");
		      int noOfLines = input.nextInt();
		      input.nextLine();
		      for(int i=1;i<= noOfLines;i++) {
		    	  System.out.print("Enter the line"+i+":");
		    	  String myLine = input.nextLine()+"\n";
			      obj.toWrite(myWriter, myLine);
		      }
		      myWriter.close();
		      System.out.println("Successfully wrote to the file.");
		      
		      Properties myProp = obj.getProperty();
		      for(int i=1;i <=5;i++) {
		    	  System.out.print("enter the key "+i+" :");
		    	  String key = input.nextLine();
		    	  System.out.print("enter the value "+i+" :");
		    	  String value = input.nextLine();
		    	  myProp = obj.setProperty(myProp, key, value);
		      }
		      String filePath = "/home/mukesh-pt7280/Desktop/day1/myProps.txt";
		      FileOutputStream fop = obj.setStream(filePath);
		       myProp = obj.store(myProp, fop, filePath);
		       System.out.print("Sucessfully Stored"); 
		      
		    } catch (IOException ioe) {
		      System.out.println("An error occurred."+ioe.getMessage());
		    } 
		 finally {
		      input.close();
   		    }

	}

}
