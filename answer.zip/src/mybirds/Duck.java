package mybirds;
public class Duck extends Bird {
    
	public void fly() {
		System.out.println("I cant fly");
	}
 
}
