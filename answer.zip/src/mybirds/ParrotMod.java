package mybirds;
public class ParrotMod extends BirdAbstract {
	
}
