package mybirds;

public abstract class Bird {
	
	public abstract void fly();
	
	public void speak() {
		System.out.println("I am speaking");
	}	
	

}
