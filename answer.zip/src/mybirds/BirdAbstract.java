package mybirds;

public abstract class BirdAbstract {
	
	public void fly() {
		System.out.println("I am flying");
	}
	
	public void speak() {
		System.out.println("I am speaking");
	}

}
