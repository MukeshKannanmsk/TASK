import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.Properties;

public class FileTask {
	
	public FileWriter getFileWriter(String path) throws IOException {
		FileWriter myWriter = new FileWriter(path);
		return myWriter;
	}
	
	public void toWrite(FileWriter myWriter,String myString) throws IOException {
		myWriter.write(myString);
	}
	
    public Properties getProperty() {
    	Properties myProp = new Properties();
    	return myProp;
    }
    
    public Properties setProperty(Properties myProp,String key,String value) {
    	myProp.setProperty(key, value);
    	return myProp;
    }
    
    public FileOutputStream setStream(String path) throws FileNotFoundException {
    	FileOutputStream myOutStream = new FileOutputStream(path);
    	return myOutStream;
    }
    
    public Properties store(Properties myProp,FileOutputStream fop,String path) throws IOException {
    	myProp.store(fop, path);
    	return myProp;
    }
    
    public Properties toRead(Properties myProp,Reader myReader) throws IOException {
    	myProp.load(myReader);
    	return myProp;
    }
}   
